# LambdaSchool Free Mini Bootcamp Homework 3 #

## Task One ##

1. Fork this repository

2. Clone it to your own machine

3. Edit the information below:


```

My name is:

I like to:

I'm learning:

```

4. Add a screenshot (.jpg or .png is fine) of a tweet you've altered using Inspect Element in Chrome to the project folder.

4. Push it up to your own repository on Github (don't try to override the original).

## Task Two ##

1. Create a new repository on Github at github.com/yourusername/hellolambdaschool.

2. Inside that repository create a file at README.md, and enter the following in that file:

```
I am learning how to use git at Lambda School's [online code bootcamp](https://lambdaschool.com/mini-bootcamp)
```

3. Push your changes to your new repository.

That's it. Good luck!

*For extra credit, practice this a few times with a few different repositories.*